#include <stdio.h>
#include <stdlib.h>
void double_free_81() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 81;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_81();
    return 0;
}
