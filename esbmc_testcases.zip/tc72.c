#include <stdio.h>
#include <limits.h>
void int_overflow_72() {
    int x = INT_MAX - (72);
    // Overflow
    x += 82;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_72();
    return 0;
}
