#include <stdio.h>
#include <limits.h>
void int_overflow_61() {
    int x = INT_MAX - (61);
    // Overflow
    x += 71;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_61();
    return 0;
}
