#include <stdio.h>
#include <stdlib.h>
void div_zero_51() {
    int x = 51 - 51;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_51();
    return 0;
}
