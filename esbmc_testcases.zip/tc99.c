#include <pthread.h>
#include <stdio.h>
int shared_99 = 0;
void* inc_99(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_99++;  // Race
    }
    return NULL;
}
void* dec_99(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_99--;  // Race
    }
    return NULL;
}
int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, inc_99, NULL);
    pthread_create(&t2, NULL, dec_99, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("shared = %d\n", shared_99);
    return 0;
}
