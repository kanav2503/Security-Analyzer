#include <stdio.h>
#include <stdlib.h>
// Memory leak example
void mem_leak_86() {
    int *p = malloc(10 * sizeof(int));
    if(!p) return;
    for(int k = 0; k < 10; k++) {
        p[k] = k * 86;
    }
    printf("p[0] = %d\n", p[0]);
    // No free => leak
}
// main
int main() {
    mem_leak_86();
    return 0;
}
