#include <stdio.h>
#include <stdlib.h>
void double_free_147() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 147;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_147();
    return 0;
}
