#include <pthread.h>
#include <stdio.h>
int shared_88 = 0;
void* inc_88(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_88++;  // Race
    }
    return NULL;
}
void* dec_88(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_88--;  // Race
    }
    return NULL;
}
int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, inc_88, NULL);
    pthread_create(&t2, NULL, dec_88, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("shared = %d\n", shared_88);
    return 0;
}
