#include <stdio.h>
#include <limits.h>
void int_overflow_127() {
    int x = INT_MAX - (127);
    // Overflow
    x += 137;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_127();
    return 0;
}
