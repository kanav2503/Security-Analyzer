#include <stdio.h>
#include <stdlib.h>
void div_zero_106() {
    int x = 106 - 106;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_106();
    return 0;
}
