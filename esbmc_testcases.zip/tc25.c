#include <stdio.h>
#include <stdlib.h>
void null_deref_25() {
    int *p = NULL;
    // Null dereference
    *p = 25;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_25();
    return 0;
}
