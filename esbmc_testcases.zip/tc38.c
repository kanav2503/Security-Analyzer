#include <stdio.h>
#include <stdlib.h>
void misaligned_38() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 38;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_38();
    return 0;
}
