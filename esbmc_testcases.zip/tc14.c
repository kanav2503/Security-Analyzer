#include <stdio.h>
#include <stdlib.h>
void null_deref_14() {
    int *p = NULL;
    // Null dereference
    *p = 14;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_14();
    return 0;
}
