#include <stdio.h>
#include <stdlib.h>
void double_free_59() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 59;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_59();
    return 0;
}
