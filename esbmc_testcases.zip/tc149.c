#include <stdio.h>
#include <limits.h>
void int_overflow_149() {
    int x = INT_MAX - (149);
    // Overflow
    x += 159;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_149();
    return 0;
}
