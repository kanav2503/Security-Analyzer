#include <stdio.h>
#include <stdlib.h>
void double_free_103() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 103;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_103();
    return 0;
}
