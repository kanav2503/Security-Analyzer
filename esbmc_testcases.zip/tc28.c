#include <stdio.h>
#include <limits.h>
void int_overflow_28() {
    int x = INT_MAX - (28);
    // Overflow
    x += 38;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_28();
    return 0;
}
