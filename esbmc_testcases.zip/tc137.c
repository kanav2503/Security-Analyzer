#include <stdio.h>
#include <stdlib.h>
void misaligned_137() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 137;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_137();
    return 0;
}
