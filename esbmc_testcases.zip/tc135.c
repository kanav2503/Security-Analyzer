#include <stdio.h>
#include <stdlib.h>
void null_deref_135() {
    int *p = NULL;
    // Null dereference
    *p = 135;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_135();
    return 0;
}
