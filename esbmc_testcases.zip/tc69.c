#include <stdio.h>
#include <stdlib.h>
void null_deref_69() {
    int *p = NULL;
    // Null dereference
    *p = 69;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_69();
    return 0;
}
