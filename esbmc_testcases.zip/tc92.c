#include <stdio.h>
#include <stdlib.h>
void double_free_92() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 92;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_92();
    return 0;
}
