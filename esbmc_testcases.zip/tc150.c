#include <stdio.h>
#include <stdlib.h>
void div_zero_150() {
    int x = 150 - 150;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_150();
    return 0;
}
