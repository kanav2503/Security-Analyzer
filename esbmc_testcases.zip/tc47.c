#include <stdio.h>
#include <stdlib.h>
void null_deref_47() {
    int *p = NULL;
    // Null dereference
    *p = 47;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_47();
    return 0;
}
