#include <stdio.h>
#include <stdlib.h>
void misaligned_126() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 126;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_126();
    return 0;
}
