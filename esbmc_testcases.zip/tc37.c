#include <stdio.h>
#include <stdlib.h>
void double_free_37() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 37;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_37();
    return 0;
}
