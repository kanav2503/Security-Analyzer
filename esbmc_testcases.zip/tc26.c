#include <stdio.h>
#include <stdlib.h>
void double_free_26() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 26;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_26();
    return 0;
}
