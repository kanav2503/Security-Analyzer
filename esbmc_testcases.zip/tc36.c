#include <stdio.h>
#include <stdlib.h>
void null_deref_36() {
    int *p = NULL;
    // Null dereference
    *p = 36;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_36();
    return 0;
}
