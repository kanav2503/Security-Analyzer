#include <stdio.h>
#include <limits.h>
void int_overflow_17() {
    int x = INT_MAX - (17);
    // Overflow
    x += 27;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_17();
    return 0;
}
