#include <stdio.h>
#include <stdlib.h>
void div_zero_18() {
    int x = 18 - 18;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_18();
    return 0;
}
