#include <pthread.h>
#include <stdio.h>
int shared_143 = 0;
void* inc_143(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_143++;  // Race
    }
    return NULL;
}
void* dec_143(void* arg) {
    for(int k = 0; k < 1000; k++) {
        shared_143--;  // Race
    }
    return NULL;
}
int main() {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, inc_143, NULL);
    pthread_create(&t2, NULL, dec_143, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("shared = %d\n", shared_143);
    return 0;
}
