#include <stdio.h>
#include <stdlib.h>
void dynamic_oob_79() {
    int n = 5;
    int *p = malloc(n * sizeof(int));
    if(!p) return;
    for(int k = 0; k < n; k++) p[k] = k;
    // OOB access
    p[n] = 42;
    printf("p[n] = %d\n", p[n]);
    free(p);
}
int main() {
    dynamic_oob_79();
    return 0;
}
