#include <stdio.h>
#include <stdlib.h>
void div_zero_95() {
    int x = 95 - 95;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_95();
    return 0;
}
