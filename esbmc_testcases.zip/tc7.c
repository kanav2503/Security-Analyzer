#include <stdio.h>
#include <stdlib.h>
void div_zero_7() {
    int x = 7 - 7;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_7();
    return 0;
}
