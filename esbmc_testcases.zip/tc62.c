#include <stdio.h>
#include <stdlib.h>
void div_zero_62() {
    int x = 62 - 62;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_62();
    return 0;
}
