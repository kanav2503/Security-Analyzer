#include <stdio.h>
#include <stdlib.h>
void div_zero_117() {
    int x = 117 - 117;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_117();
    return 0;
}
