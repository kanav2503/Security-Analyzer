#include <stdio.h>
#include <stdlib.h>
void div_zero_40() {
    int x = 40 - 40;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_40();
    return 0;
}
