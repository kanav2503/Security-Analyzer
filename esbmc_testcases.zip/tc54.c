#include <pthread.h>
#include <stdio.h>
pthread_mutex_t m1, m2;
void* t1_54(void* arg) {
    pthread_mutex_lock(&m1);
    pthread_mutex_lock(&m2);
    pthread_mutex_unlock(&m2);
    pthread_mutex_unlock(&m1);
    return NULL;
}
void* t2_54(void* arg) {
    pthread_mutex_lock(&m2);
    pthread_mutex_lock(&m1);
    pthread_mutex_unlock(&m1);
    pthread_mutex_unlock(&m2);
    return NULL;
}
int main() {
    pthread_t a, b;
    pthread_mutex_init(&m1, NULL);
    pthread_mutex_init(&m2, NULL);
    pthread_create(&a, NULL, t1_54, NULL);
    pthread_create(&b, NULL, t2_54, NULL);
    pthread_join(a, NULL);
    pthread_join(b, NULL);
    return 0;
}
