#include <stdio.h>
#include <stdlib.h>
void double_free_70() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 70;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_70();
    return 0;
}
