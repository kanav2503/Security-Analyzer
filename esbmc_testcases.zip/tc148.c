#include <stdio.h>
#include <stdlib.h>
void misaligned_148() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 148;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_148();
    return 0;
}
