#include <stdio.h>
#include <stdlib.h>
void null_deref_146() {
    int *p = NULL;
    // Null dereference
    *p = 146;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_146();
    return 0;
}
