#include <stdio.h>
#include <stdlib.h>
void misaligned_71() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 71;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_71();
    return 0;
}
