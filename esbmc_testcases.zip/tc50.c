#include <stdio.h>
#include <limits.h>
void int_overflow_50() {
    int x = INT_MAX - (50);
    // Overflow
    x += 60;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_50();
    return 0;
}
