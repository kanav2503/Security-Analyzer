#include <stdio.h>
#include <stdlib.h>
void double_free_114() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 114;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_114();
    return 0;
}
