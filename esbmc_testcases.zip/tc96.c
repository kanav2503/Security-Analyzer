#include <stdio.h>
#include <math.h>
void nan_test_96() {
    float a = 0.0f;
    // NaN creation
    float n = a / a;
    if(isnan(n)) {
        printf("Got NaN\n");
    }
}
int main() {
    nan_test_96();
    return 0;
}
