#include <stdio.h>
#include <stdlib.h>
void misaligned_115() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 115;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_115();
    return 0;
}
