#include <stdio.h>
#include <stdlib.h>
void null_deref_124() {
    int *p = NULL;
    // Null dereference
    *p = 124;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_124();
    return 0;
}
