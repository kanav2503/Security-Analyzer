#include <stdio.h>
#include <stdlib.h>
void double_free_136() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 136;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_136();
    return 0;
}
