#include <stdio.h>
#include <limits.h>
void int_overflow_39() {
    int x = INT_MAX - (39);
    // Overflow
    x += 49;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_39();
    return 0;
}
