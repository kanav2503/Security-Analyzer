#include <stdio.h>
#include <stdlib.h>
void div_zero_128() {
    int x = 128 - 128;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_128();
    return 0;
}
