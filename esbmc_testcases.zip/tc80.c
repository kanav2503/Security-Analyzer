#include <stdio.h>
#include <stdlib.h>
void null_deref_80() {
    int *p = NULL;
    // Null dereference
    *p = 80;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_80();
    return 0;
}
