#include <stdio.h>
#include <stdlib.h>
void misaligned_49() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 49;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_49();
    return 0;
}
