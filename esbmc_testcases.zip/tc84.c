#include <stdio.h>
#include <stdlib.h>
void div_zero_84() {
    int x = 84 - 84;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_84();
    return 0;
}
