#include <stdio.h>
#include <stdlib.h>
void double_free_15() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 15;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_15();
    return 0;
}
