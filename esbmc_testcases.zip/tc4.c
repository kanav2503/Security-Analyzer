#include <stdio.h>
#include <stdlib.h>
void double_free_4() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 4;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_4();
    return 0;
}
