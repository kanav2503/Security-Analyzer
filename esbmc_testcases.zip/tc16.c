#include <stdio.h>
#include <stdlib.h>
void misaligned_16() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 16;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_16();
    return 0;
}
