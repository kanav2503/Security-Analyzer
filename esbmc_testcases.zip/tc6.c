#include <stdio.h>
#include <limits.h>
void int_overflow_6() {
    int x = INT_MAX - (6);
    // Overflow
    x += 16;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_6();
    return 0;
}
