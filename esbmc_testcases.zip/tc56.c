#include <stdio.h>
#include <stdlib.h>
#define SIZE 6
void static_oob_56() {
    int arr[SIZE];
    for(int j = 0; j < SIZE; j++) {
        arr[j] = j;
    }
    // OOB access
    arr[SIZE] = 99; // Out-of-bounds write
    printf("arr[SIZE] = %d\n", arr[SIZE]);
}
int main() {
    static_oob_56();
    return 0;
}
