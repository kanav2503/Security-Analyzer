#include <stdio.h>
#include <limits.h>
void int_overflow_105() {
    int x = INT_MAX - (105);
    // Overflow
    x += 115;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_105();
    return 0;
}
