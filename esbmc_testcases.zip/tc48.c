#include <stdio.h>
#include <stdlib.h>
void double_free_48() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 48;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_48();
    return 0;
}
