#include <stdio.h>
#include <stdlib.h>
void misaligned_104() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 104;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_104();
    return 0;
}
