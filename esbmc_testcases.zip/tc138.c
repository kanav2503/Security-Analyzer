#include <stdio.h>
#include <limits.h>
void int_overflow_138() {
    int x = INT_MAX - (138);
    // Overflow
    x += 148;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_138();
    return 0;
}
