#include <stdio.h>
#include <limits.h>
void int_overflow_83() {
    int x = INT_MAX - (83);
    // Overflow
    x += 93;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_83();
    return 0;
}
