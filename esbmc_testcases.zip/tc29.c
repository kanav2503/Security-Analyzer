#include <stdio.h>
#include <stdlib.h>
void div_zero_29() {
    int x = 29 - 29;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_29();
    return 0;
}
