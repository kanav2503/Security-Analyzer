#include <stdio.h>
#include <stdlib.h>
void null_deref_113() {
    int *p = NULL;
    // Null dereference
    *p = 113;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_113();
    return 0;
}
