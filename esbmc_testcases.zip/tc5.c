#include <stdio.h>
#include <stdlib.h>
void misaligned_5() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 5;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_5();
    return 0;
}
