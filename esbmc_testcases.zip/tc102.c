#include <stdio.h>
#include <stdlib.h>
void null_deref_102() {
    int *p = NULL;
    // Null dereference
    *p = 102;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_102();
    return 0;
}
