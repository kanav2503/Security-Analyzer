#include <stdio.h>
#include <stdlib.h>
void misaligned_82() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 82;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_82();
    return 0;
}
