#include <stdio.h>
#include <stdlib.h>
void null_deref_58() {
    int *p = NULL;
    // Null dereference
    *p = 58;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_58();
    return 0;
}
