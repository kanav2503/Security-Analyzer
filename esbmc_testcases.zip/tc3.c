#include <stdio.h>
#include <stdlib.h>
void null_deref_3() {
    int *p = NULL;
    // Null dereference
    *p = 3;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_3();
    return 0;
}
