#include <stdio.h>
#include <limits.h>
void int_overflow_116() {
    int x = INT_MAX - (116);
    // Overflow
    x += 126;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_116();
    return 0;
}
