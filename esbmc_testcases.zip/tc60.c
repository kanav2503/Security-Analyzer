#include <stdio.h>
#include <stdlib.h>
void misaligned_60() {
    char buf[sizeof(int)*2];
    int *p = (int*)(buf + 1);
    // Misaligned write
    *p = 60;
    printf("misaligned p: %d\n", *p);
}
int main() {
    misaligned_60();
    return 0;
}
