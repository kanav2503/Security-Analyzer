#include <stdio.h>
#include <stdlib.h>
void null_deref_91() {
    int *p = NULL;
    // Null dereference
    *p = 91;
    printf("p points to %d\n", *p);
}
int main() {
    null_deref_91();
    return 0;
}
