#include <stdio.h>
#include <stdlib.h>
void div_zero_73() {
    int x = 73 - 73;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_73();
    return 0;
}
