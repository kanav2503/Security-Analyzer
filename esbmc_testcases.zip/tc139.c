#include <stdio.h>
#include <stdlib.h>
void div_zero_139() {
    int x = 139 - 139;
    // Divide by zero
    int y = 100 / x;
    printf("y = %d\n", y);
}
int main() {
    div_zero_139();
    return 0;
}
