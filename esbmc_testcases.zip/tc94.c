#include <stdio.h>
#include <limits.h>
void int_overflow_94() {
    int x = INT_MAX - (94);
    // Overflow
    x += 104;
    printf("x = %d\n", x);
}
int main() {
    int_overflow_94();
    return 0;
}
