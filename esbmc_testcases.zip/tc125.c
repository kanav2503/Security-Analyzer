#include <stdio.h>
#include <stdlib.h>
void double_free_125() {
    int *q = malloc(sizeof(int));
    if(!q) return;
    *q = 125;
    free(q);
    // Double free
    free(q);
}
int main() {
    double_free_125();
    return 0;
}
